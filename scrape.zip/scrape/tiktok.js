const axios = require('axios');

module.exports = {
    tiktok: async (url, version) => {
        try {
            let res;
            if (version === 'v1') {
                const { data } = await axios.get('https://ikyyzyyrestapi.my.id/download/tiktok', { params: { apikey: "kyzz", query: url } });
                return data;
            } else if (version === 'v2') {
                const { data } = await axios.get('https://ikyyzyyrestapi.my.id/download/tiktokv2', { params: { url } });
                return data;
            } else if (version === 'v3') {
                const { data } = await axios.get('https://www.tikwm.com/api/', { params: { url } });
                return { status: data.code === 0, result: data.data };
            } else if (version === 'v4') {
                const { data } = await axios.get('https://tikdown.ikyzxz.my.id/api/v1', { params: { url } });
                return data;
            } else if (version === 'v5') {
                const { data } = await axios.get('https://ikyyzyyrestapi.my.id/download/tiktokv3', { params: { url } });
                return data;
            } else if (version === 'v6') {
                const { data } = await axios.get('https://ikyyzyyrestapi.my.id/download/tiktokv4', { params: { url } });
                return data;
            }
        } catch (e) {
            return { status: false, message: e.message };
        }
    }
};

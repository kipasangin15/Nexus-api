const axios = require('axios');

async function deepNude(url) {
    try {
        if (!url) throw new Error("URL gambar harus disertakan!");

        const response = await axios.get(`https://api.danzy.web.id/api/maker/deepnude`, {
            params: { url: url },
            responseType: 'arraybuffer',
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        const buffer = Buffer.from(response.data, 'binary');

        return {
            status: true,
            data: buffer
        };
    } catch (e) {
        return {
            status: false,
            message: e.message
        };
    }
}

module.exports = { deepNude };

const os = require('os');

function getSystemStatus() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);

    return {
        status: "Operational",
        uptime: `${hours}h ${minutes}m ${seconds}s`,
        ram_usage: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`,
        platform: os.platform(),
        engine: "Nexus-Scrape V1"
    };
}

module.exports = { getSystemStatus };

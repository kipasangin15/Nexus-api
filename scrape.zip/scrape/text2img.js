const axios = require('axios');

async function text2Img(text) {
    try {
        const response = await axios.get(`https://ikyyzyyrestapi.my.id/ai/gptimage?text=${encodeURIComponent(text)}`, {
            responseType: 'arraybuffer'
        });
        return { status: true, data: Buffer.from(response.data, 'binary') };
    } catch (e) {
        return { status: false, message: e.message };
    }
}

module.exports = { text2Img };

const axios = require('axios');

async function bratMaker(text) {
    try {
        const response = await axios.get(`https://api.siputzx.my.id/api/m/brat`, {
            params: { 
                text: text,
                delay: 500 
            },
            responseType: 'arraybuffer',
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        const buffer = Buffer.from(response.data, 'binary');

        return {
            status: true,
            data: buffer
        };
    } catch (e) {
        return {
            status: false,
            message: e.message
        };
    }
}

module.exports = { bratMaker };

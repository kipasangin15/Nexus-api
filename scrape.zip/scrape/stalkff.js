const axios = require('axios');
const { randomUUID } = require('node:crypto');

async function ffStalk(id) {
    const h = {
        "User-Agent": "Mozilla/5.0",
        "X-Device": randomUUID(),
    };
    const tResp = await axios.post("https://api.duniagames.co.id/api/item-catalog/v1/get-token", { msisdn: "0812665588" }, { headers: h });
    const t = tResp.data.data.token;
    
    const nResp = await axios.post("https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store", {
        productId: 3, itemId: 353, product_ref: "REG", product_ref_denom: "REG",
        catalogId: 376, paymentId: 1252, gameId: id, token: t, campaignUrl: ""
    }, { headers: h });

    return { id, name: nResp.data.data.gameDetail.userName };
}

module.exports = { ffStalk };


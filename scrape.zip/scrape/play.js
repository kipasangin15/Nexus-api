const axios = require('axios');

module.exports = {
    spotifyPlay: async (query) => {
        try {
            const { data } = await axios.get('https://ikyyzyyrestapi.my.id/search/spotifyplay', {
                params: { query }
            });
            if (!data.status) return { status: false, message: "Lagu tidak ditemukan" };
            return { status: true, result: data.result };
        } catch (e) {
            return { status: false, message: e.message };
        }
    }
};

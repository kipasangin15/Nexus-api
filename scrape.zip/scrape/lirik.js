const axios = require('axios');
const cheerio = require('cheerio');

async function getLirik(lagu) {
    try {
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(lagu + ' lirik')}&hl=id`;
        const { data } = await axios.get(searchUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "Referer": "https://www.google.com/"
            }
        });

        const $ = cheerio.load(data);
        let lirik = "";

        // Urutan selector paling akurat (Master Bug Fix)
        lirik = $("div.hw697c").text() || 
                $("div[jsname='W9S7Cc']").text() || 
                $("div.BNeawe.tAd7D.AP7Wnd").text();

        // Fallback jika Google nampilin lirik di bawah judul (layout mobile)
        if (!lirik) {
            $('.BNeawe.s3v9rd.AP7Wnd').each((i, el) => {
                let text = $(el).text();
                if (text.length > 100 && text.includes('\n')) {
                    lirik = text;
                    return false;
                }
            });
        }

        if (!lirik) {
            return { status: false, message: "Lirik tidak ditemukan di elemen Google." };
        }

        return {
            status: true,
            title: lagu,
            lirik: lirik.trim()
        };
    } catch (e) {
        return {
            status: false,
            message: "Google memblokir koneksi: " + e.message
        };
    }
}

module.exports = { getLirik };

const express = require('express');
const cors = require('cors');

const { getSystemStatus } = require('./scrape/cekstatus');
const { ffStalk } = require('./scrape/stalkff');
const { getLirik } = require('./scrape/lirik');
const { bratMaker } = require('./scrape/brat');
const { deepNude } = require('./scrape/deepnude');
const { text2Img } = require('./scrape/text2img');

const app = express();
app.use(cors());

app.get('/api/status', (req, res) => {
    try {
        const stats = getSystemStatus();
        res.json({ status: true, creator: "James", result: stats });
    } catch (e) {
        res.status(500).json({ status: false, error: e.message });
    }
});

app.get('/api/stalkff', async (req, res) => {
    try {
        const { id } = req.query;
        if (!id) return res.status(400).json({ status: false, message: "ID mana?" });
        const result = await ffStalk(id);
        res.json({ status: true, creator: "James", result });
    } catch (e) {
        res.status(500).json({ status: false, error: e.message });
    }
});

const handleImageRequest = async (req, res, fn, param) => {
    try {
        const input = req.query[param];
        if (!input) return res.status(400).json({ status: false, message: `${param} mana?` });
        const result = await fn(input);
        if (result.status) {
            res.set('Content-Type', 'image/png');
            res.send(result.data);
        } else {
            res.status(500).json({ status: false, message: result.message });
        }
    } catch (e) {
        res.status(500).json({ status: false, error: e.message });
    }
};

app.get('/api/brat', (req, res) => handleImageRequest(req, res, bratMaker, 'text'));
app.get('/api/deepnude', (req, res) => handleImageRequest(req, res, deepNude, 'url'));
app.get('/api/text2img', (req, res) => handleImageRequest(req, res, text2Img, 'text'));

app.get('/api/lirik', async (req, res) => {
    try {
        const { lagu } = req.query;
        if (!lagu) return res.status(400).json({ status: false, message: "Judul mana?" });
        const data = await getLirik(lagu);
        if (data.status) {
            res.json({ status: true, creator: "James", result: { title: data.title, lirik: data.lirik } });
        } else {
            res.status(404).json({ status: false, message: data.message });
        }
    } catch (e) {
        res.status(500).json({ status: false, error: e.message });
    }
});

module.exports = app;
